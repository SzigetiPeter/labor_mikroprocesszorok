/*
 * light_sensor.c
 */

#include "i2c.h"
#include "main.h"
#include "light_sensor.h"
#include <math.h>
#include <stdio.h>

// Alapértelmezett címbeállítás
uint8_t LightSensor_Address = LightSensor_ADDR_FLOAT;

// I2C cím beállítása
void LightSensor_SetAddress(uint8_t address)
{
	LightSensor_Address = address;
}

// Parancs küldése a szenzornak
HAL_StatusTypeDef LightSensor_Cmd(uint8_t cmd)
{
	HAL_StatusTypeDef status;

	status = HAL_I2C_Master_Transmit(&hi2c1, LightSensor_Address, &cmd, 1, LightSensor_Timeout);

	return status;
}

// Egy utasítás írása a szenzor kiválasztott regiszterébe
HAL_StatusTypeDef LightSensor_Write(uint8_t reg, uint8_t value)
{
	uint8_t data[2];
	HAL_StatusTypeDef status;

	data[0] = reg | LightSensor_CMDREG_CMD;
	data[1] = value;

	status = HAL_I2C_Master_Transmit(&hi2c1, LightSensor_Address, data, 2, LightSensor_Timeout);

	return status;

}

// Szó írása a szenzor kiválasztott regiszterébe
HAL_StatusTypeDef LightSensor_WriteWord(uint8_t reg, uint16_t value)
{
	uint8_t data[3];
	HAL_StatusTypeDef status;

	data[0] = LightSensor_CMDREG_CMD | LightSensor_CMDREG_WORD | reg;
	// Type conversion does not required, but in that way it is more clear
	data[1] = (uint8_t)(value); // value & 0x00FF gives the same result
	data[2] = (uint8_t)(value >> 8);

	status = HAL_I2C_Master_Transmit(&hi2c1, LightSensor_Address, data, 3, LightSensor_Timeout);

	return status;

}
// Egy bájt olvasása a szenzor kiválasztott regiszteréből
HAL_StatusTypeDef LightSensor_Read(uint8_t reg, uint8_t* value)
{
	uint8_t data_tx;
	HAL_StatusTypeDef status_tx, status_rx;

	data_tx = reg | LightSensor_CMDREG_CMD;

	status_tx = HAL_I2C_Master_Transmit(&hi2c1, LightSensor_Address, &data_tx, 1, LightSensor_Timeout);
	status_rx = HAL_I2C_Master_Receive(&hi2c1, LightSensor_Address, value, 1, LightSensor_Timeout);

	return (status_tx == HAL_OK && status_rx == HAL_OK) ? HAL_OK : HAL_ERROR;

}
// Szenzor teljesítménymódjának beállítása
HAL_StatusTypeDef LightSensor_SetPowerState(uint8_t state)
{
	HAL_StatusTypeDef status;
	status = LightSensor_Write(LightSensor_REG_CONTROL, state);

	return status;

}
// Erősítés beállítása a szenzor ADC-jének
HAL_StatusTypeDef LightSensor_SetGain(uint8_t gain)
{
	uint8_t regState;
	HAL_StatusTypeDef status_tx, status_rx;

	status_tx = LightSensor_Read(LightSensor_REG_TIMING, &regState);
	regState &= LightSensor_GAIN_MASK;
	regState |= gain;
	status_rx =LightSensor_Write(LightSensor_REG_TIMING, regState);

	return (status_tx == HAL_OK && status_rx == HAL_OK) ? HAL_OK : HAL_ERROR;

}
// Integrálási idő beállítása a szenzor ADC-jének
HAL_StatusTypeDef LightSensor_SetIntegrationTime(uint8_t time)
{
	uint8_t regState;
	HAL_StatusTypeDef status_tx, status_rx;

	status_tx = LightSensor_Read(LightSensor_REG_TIMING, &regState);
	regState &= LightSensor_INTEG_MASK;
	regState |= time;
	status_rx = LightSensor_Write(LightSensor_REG_TIMING, regState);

	return (status_tx == HAL_OK && status_rx == HAL_OK) ? HAL_OK : HAL_ERROR;

}
// Megszakítást jelző bit törlése a szenzorban
HAL_StatusTypeDef LightSensor_ClearInterrupt()
{
	HAL_StatusTypeDef status;

	status = LightSensor_Cmd(LightSensor_CMDREG_CMD | LightSensor_CMDREG_CLEARINT);

	return status;
}
// Szenzor megszakítás állapotának beállítása
HAL_StatusTypeDef LightSensor_SetInterruptState(uint8_t state)
{
	uint8_t regState;
	HAL_StatusTypeDef status_tx, status_rx;

	status_tx = LightSensor_Read(LightSensor_REG_INTERRUPT, &regState);
	regState &= LightSensor_INT_MASK;
	regState |= state;
	status_rx = LightSensor_Write(LightSensor_REG_INTERRUPT, regState);

	return (status_tx == HAL_OK && status_rx == HAL_OK) ? HAL_OK : HAL_ERROR;
}
// Az érzékelő megszakítási perzisztenciájának beállítása
HAL_StatusTypeDef LightSensor_SetInterruptPersist(uint8_t persist)
{
	uint8_t regState;
	HAL_StatusTypeDef status_tx, status_rx;

	status_tx = LightSensor_Read(LightSensor_REG_INTERRUPT, &regState);
	regState &= LightSensor_PERSIST_MASK;
	regState |= persist;
	status_rx = LightSensor_Write(LightSensor_REG_INTERRUPT, regState);

	return (status_tx == HAL_OK && status_rx == HAL_OK) ? HAL_OK : HAL_ERROR;

}
// Megszakítási határok beállítása
HAL_StatusTypeDef LightSensor_SetThreshold(uint16_t lower, uint16_t upper)
{
	HAL_StatusTypeDef status_lower, status_upper;

	uint8_t pData_lower[3];
	uint8_t pData_upper[3];

	pData_lower[0] = LightSensor_CMDREG_CMD | LightSensor_CMDREG_WORD | LightSensor_REG_THRESHLOWLOW;
	pData_lower[1] = lower & 0x00FF;
	pData_lower[2] = lower >> 8;

	pData_upper[0] = LightSensor_CMDREG_CMD | LightSensor_CMDREG_WORD | LightSensor_REG_THRESHHIGHLOW;
	pData_upper[1] = upper & 0x00FF;
	pData_upper[2] = upper >> 8;

	status_lower = HAL_I2C_Master_Transmit(&hi2c1, LightSensor_Address, pData_lower, 3, LightSensor_Timeout);
	status_upper = HAL_I2C_Master_Transmit(&hi2c1, LightSensor_Address, pData_upper, 3, LightSensor_Timeout);

	return (status_lower == HAL_OK && status_upper == HAL_OK) ? HAL_OK : HAL_ERROR;

}
// Szenzor ADC-jének az integrálási idejének kiolvasása
HAL_StatusTypeDef LightSensor_GetIntegrationTime(uint8_t* regVal)
{
	HAL_StatusTypeDef status;

	status = LightSensor_Read(LightSensor_REG_TIMING, regVal);
	*regVal &= ~(uint8_t)LightSensor_INTEG_MASK;

	return status;

}
// Szenzor ADC-jének erősítésének kiolvasása
HAL_StatusTypeDef LightSensor_GetGain(uint8_t* regVal)
{
	HAL_StatusTypeDef status;

	status = LightSensor_Read(LightSensor_REG_TIMING, regVal);
	*regVal &= ~(uint8_t)LightSensor_GAIN_MASK;
//	*regVal = (*regVal)>>LightSensor_GAIN_POS;

	return status;

}
// Szenzor 0-s csatornájának kiolvasása.
HAL_StatusTypeDef LightSensor_GetCH0Value(uint16_t* value)
{
	uint8_t data = LightSensor_CMDREG_CMD | LightSensor_CMDREG_WORD | LightSensor_REG_DATA0LOW;
	uint8_t regVal[2] = {0, 0};
	HAL_StatusTypeDef stat_tx, stat_rx = HAL_ERROR;

	stat_tx = HAL_I2C_Master_Transmit(&hi2c1, LightSensor_Address, &data, 1, LightSensor_Timeout);
	if (stat_tx == HAL_OK)
	{
		stat_rx = HAL_I2C_Master_Receive(&hi2c1, LightSensor_Address, regVal, 2, LightSensor_Timeout);
	}

	// Csak sikeres olvasás után írjuk felül a kimenetet. Hiba esetén a regVal tartalma
	// érvénytelen: ha mégis kiírnánk, a kijelzett érték "befagyna" egy véletlen számon.
	if (stat_tx != HAL_OK || stat_rx != HAL_OK)
	{
		return HAL_ERROR;
	}

	*value = (regVal[1]<<8) + regVal[0];

	return HAL_OK;

}
// Szenzor 1-es csatornájának kiolvasása.
HAL_StatusTypeDef LightSensor_GetCH1Value(uint16_t* value)
{
	uint8_t data = LightSensor_CMDREG_CMD | LightSensor_CMDREG_WORD | LightSensor_REG_DATA1LOW;
	uint8_t regVal[2] = {0, 0};
	HAL_StatusTypeDef stat_tx, stat_rx = HAL_ERROR;

	stat_tx = HAL_I2C_Master_Transmit(&hi2c1, LightSensor_Address, &data, 1, LightSensor_Timeout);
	if (stat_tx == HAL_OK)
	{
		stat_rx = HAL_I2C_Master_Receive(&hi2c1, LightSensor_Address, regVal, 2, LightSensor_Timeout);
	}

	// Csak sikeres olvasás után írjuk felül a kimenetet. Hiba esetén a regVal tartalma
	// érvénytelen: ha mégis kiírnánk, a kijelzett érték "befagyna" egy véletlen számon.
	if (stat_tx != HAL_OK || stat_rx != HAL_OK)
	{
		return HAL_ERROR;
	}

	*value = (regVal[1]<<8) + regVal[0];

	return HAL_OK;

}
// Fényintezitás kiolvasása a szenzorból lux mértékegységben.
HAL_StatusTypeDef LightSensor_GetLightLevel(float* lightLevel)
{
	uint16_t CH0_value_int, CH1_value_int;
	uint8_t gain;
	uint8_t integrationTime;

	float CH0_value, CH1_value;
	float ratio;
	float time_scale;
	uint16_t max_count;

	/*
	 * 0-s és 1-es csatorna, valamint az erősítés és az integrálási idő kiolvasása,
	 * mivel ezek az adatok kellenek az aktuális fényintenzitás kiszámításához.
	 * Ha bármelyik olvasás sikertelen, a *lightLevel nem változik.
	 */
	if (LightSensor_GetCH0Value(&CH0_value_int) != HAL_OK ||
		LightSensor_GetCH1Value(&CH1_value_int) != HAL_OK ||
		LightSensor_GetGain(&gain) != HAL_OK ||
		LightSensor_GetIntegrationTime(&integrationTime) != HAL_OK)
	{
		return HAL_ERROR;
	}

	/*
	 * Az adatlap képlete 402 ms integrálási időre vonatkozik, rövidebb időnél a mért
	 * értéket 322/11, illetve 322/81 arányban kell felszorozni. A 322.0f miatt ez
	 * lebegőpontos osztás (a 322/81 egész osztásként 3 lenne 3.975 helyett).
	 * A max_count az adott integrálási időnél elérhető legnagyobb érték: ha egy
	 * csatorna eléri, a szenzor telítődött, és a lux nem számolható ki.
	 */
	switch (integrationTime)
	{
		case LightSensor_INTEG_13m7:
			time_scale = 322.0f / 11.0f;
			max_count = 5047;
			break;
		case LightSensor_INTEG_101m:
			time_scale = 322.0f / 81.0f;
			max_count = 37177;
			break;
		case LightSensor_INTEG_402m:
			time_scale = 1.0f;
			max_count = 65535;
			break;
		default:
			// Kézi integrálás: az integrálási idő nem ismert, a lux nem számolható
			return HAL_ERROR;
	}

	// Telítődés: túl erős a fény az aktuális erősítéshez és integrálási időhöz
	if (CH0_value_int >= max_count || CH1_value_int >= max_count)
	{
		*lightLevel = LightSensor_LUX_SATURATED;
		return HAL_OK;
	}

	// Teljes sötétség: a 0-s csatorna 0, a megvilágítás is 0 lux (és nem osztunk 0-val)
	if (CH0_value_int == 0)
	{
		*lightLevel = 0.0f;
		return HAL_OK;
	}

	CH0_value = (float)CH0_value_int;
	CH1_value = (float)CH1_value_int;
	ratio = CH1_value / CH0_value;

	// Az adatlap képlete 16x erősítésre vonatkozik
	if (gain == LightSensor_GAIN_1X)
	{
		CH0_value *= 16;
		CH1_value *= 16;
	}
	CH0_value *= time_scale;
	CH1_value *= time_scale;

	/*
	 * Aktuális fényintenzitás kiszámítása lux-ban az adatlapban
	 * megadott képletnek megfelelően.
	 * A képlet az adatlap 5. oldalán található meg.
	 */
	if (ratio <= 0.52f)
	{
		*lightLevel = (0.0315f * CH0_value) - (0.0593f * CH0_value * powf(ratio, 1.4f));
	}
	else if (ratio <= 0.65f)
	{
		*lightLevel = (0.0229f * CH0_value) - (0.0291f * CH1_value);
	}
	else if (ratio <= 0.80f)
	{
		*lightLevel = (0.0157f * CH0_value) - (0.0180f * CH1_value);
	}
	else if (ratio <= 1.30f)
	{
		*lightLevel = (0.00338f * CH0_value) - (0.00260f * CH1_value);
	}
	else
	{
		*lightLevel = 0.0f;
	}

	return HAL_OK;
}

// A mért fényintenzitás szöveggé alakítása a kijelzéshez
void LightSensor_FormatLux(char* text, uint8_t size, HAL_StatusTypeDef status, float lightLevel)
{
	if (status != HAL_OK)
	{
		snprintf(text, size, "I2C error");
	}
	else if (lightLevel < 0.0f)
	{
		snprintf(text, size, "Saturated");
	}
	else
	{
		// Századokra kerekítve, egész számokkal (a %f kiíráshoz külön linker beállítás kellene).
		// A %02lu miatt a 19.05 lux "19.05" lesz, nem "19.5".
		uint32_t centi_lux = (uint32_t)(lightLevel * 100.0f + 0.5f);
		snprintf(text, size, "%lu.%02lu lux", (unsigned long)(centi_lux / 100), (unsigned long)(centi_lux % 100));
	}
}
